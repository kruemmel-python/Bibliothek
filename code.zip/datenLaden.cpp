#include "datenLaden.hpp"
#include <iostream>
#include <fstream>
#include <sstream>

// Implementierung der Funktion zum Laden der Daten aus einer JSON-�hnlichen Datei
void datenLaden(std::vector<Buch>& buecher, std::vector<Benutzer>& benutzer) {
    std::ifstream datei("daten.json");
    if (!datei) {
        std::cerr << "Fehler beim �ffnen der Datei zum Laden.\n";
        return;
    }

    std::string zeile;
    std::string name, titel, autor;
    int id = 0, verliehenAn = 0;
    bool istVerliehen = false, istBenutzer = false, istBuch = false;

    // Leere Vektoren, bevor neue Daten geladen werden
    buecher.clear();
    benutzer.clear();

    while (std::getline(datei, zeile)) {
        std::istringstream iss(zeile);
        std::string key;

        // Benutzer blockweise laden
        if (zeile.find("\"benutzer\"") != std::string::npos) {
            istBenutzer = true;
            istBuch = false;
            continue;
        }

        // Buch blockweise laden
        if (zeile.find("\"buecher\"") != std::string::npos) {
            istBenutzer = false;
            istBuch = true;
            continue;
        }

        if (istBenutzer) {
            if (zeile.find("\"name\"") != std::string::npos) {
                std::getline(iss, key, ':');
                iss >> std::ws;
                std::getline(iss, name, '"');
                std::getline(iss, name, '"');
            }
            if (zeile.find("\"id\"") != std::string::npos) {
                std::getline(iss, key, ':');
                iss >> id;
                if (id != 0) {  // Ignoriere Benutzer mit ID 0
                    benutzer.emplace_back(name, id);
                }
            }
        }

        if (istBuch) {
            if (zeile.find("\"titel\"") != std::string::npos) {
                std::getline(iss, key, ':');
                iss >> std::ws;
                std::getline(iss, titel, '"');
                std::getline(iss, titel, '"');
            }
            if (zeile.find("\"autor\"") != std::string::npos) {
                std::getline(iss, key, ':');
                iss >> std::ws;
                std::getline(iss, autor, '"');
                std::getline(iss, autor, '"');
            }
            if (zeile.find("\"id\"") != std::string::npos) {
                std::getline(iss, key, ':');
                iss >> id;
            }
            if (zeile.find("\"istVerliehen\"") != std::string::npos) {
                istVerliehen = zeile.find("true") != std::string::npos;
            }
            if (zeile.find("\"verliehenAn\"") != std::string::npos) {
                std::getline(iss, key, ':');
                // Pr�fe, ob "verliehenAn" auf null gesetzt ist
                if (zeile.find("null") != std::string::npos) {
                    verliehenAn = 0;  // Setze verliehenAn auf 0, was bedeutet, dass es nicht verliehen ist
                }
                else {
                    iss >> verliehenAn;
                }
            }

            // Buch vollst�ndig laden
            if (!titel.empty() && !autor.empty() && id != 0) {
                Buch neuesBuch;
                buchBeschreiben(neuesBuch, titel, autor, id);
                neuesBuch.istVerliehen = istVerliehen;

                // Verleihstatus pr�fen und Benutzer zuweisen
                if (istVerliehen && verliehenAn != 0) {  // Benutzer-ID 0 ist ung�ltig
                    bool benutzerGefunden = false;
                    for (auto& b : benutzer) {
                        if (b.id == verliehenAn) {
                            neuesBuch.verliehenAn = &b;
                            benutzerGefunden = true;
                            break;
                        }
                    }
                    if (!benutzerGefunden) {
                        std::cerr << "Warnung: Benutzer mit ID " << verliehenAn << " nicht gefunden.\n";
                        neuesBuch.istVerliehen = false;  // Verleihstatus zur�cksetzen
                        neuesBuch.verliehenAn = nullptr;
                    }
                }

                buecher.push_back(neuesBuch);
            }
        }
    }

    datei.close();
    std::cout << "Daten erfolgreich geladen.\n";
}
